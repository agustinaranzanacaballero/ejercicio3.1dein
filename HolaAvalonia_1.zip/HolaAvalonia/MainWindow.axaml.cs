using Avalonia.Controls;
using Avalonia.Media;

namespace HolaAvalonia;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();

        Title = "Título cambiado desde C#";
        saludo.Text = "Este texto lo ha puesto el C#";
        saludo.Foreground = Brushes.Crimson;
    }
}