using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Media;
 
namespace HolaAvalonia;   // copia aquí el namespace de MainWindow.axaml.cs
 
public class VentanaCS : Window
{
    // Campo para poder usar el TextBlock desde cualquier método
    private TextBlock saludo = null!;
 
    public VentanaCS()
    {
        InitializeComponent();
    }
 
    // Este método lo escribes tú: aquí se construye la interfaz
    private void InitializeComponent()
    {
        // 1) Propiedades de la ventana: Title, Width y Height
 
        // 2) Crea el TextBlock con tu nombre y guárdalo en "saludo"
 
        // 3) Crea el Button con el mismo texto que en MainWindow
 
        // 4) Asigna a Content un StackPanel que contenga los dos
    }
}
